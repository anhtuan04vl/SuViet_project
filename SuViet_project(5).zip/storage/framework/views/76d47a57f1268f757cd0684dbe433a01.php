<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/Logo.png" type="image/png">
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/png">
    <title>Sứ Việt</title>
    <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?> 
    <!-- link gg -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

<!-- Thêm SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body ng-app="tcApp" ng-controller="tcCtrl">
    
    <!-- menu -->
    <?php echo $__env->make('desktop.template.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- slider -->
    <?php echo $__env->yieldContent('slider'); ?>
    <?php echo $__env->yieldContent('coupon'); ?>
    <!-- content -->
    <div ng-controller="viewCtrl">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Footer -->
    <?php echo $__env->make('desktop.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
    <script src="<?php echo e(asset('/')); ?>angular.min.js"></script>
    <script>
        var app = angular.module('tcApp', []);
        app.controller('tcCtrl', function($scope){
            
        });
        var viewFunction =function($scope){}
    </script>
        <?php echo $__env->yieldContent('viewFunction'); ?>
    <script>
        app.controller('viewCtrl', viewFunction);
    </script>
</script>
</html><?php /**PATH C:\laragon\www\DATN\datnnew\SuViet_Project\SuViet_Project\SuViet_Project\resources\views/desktop/master.blade.php ENDPATH**/ ?>