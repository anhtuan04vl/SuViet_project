<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <link rel="icon" href="../img/Logo.png" type="image/png">
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/png">
    <title>Sứ Việt - Admin Dashboard</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <!-- Favicon -->
    <!-- <link href="img/Logo.png" rel="icon"> -->

    <!-- Google Web Fonts Mảnope-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Gọi file admin.js chứa Bootstrap -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/admin.js'); ?> 
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/category.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

<!-- Thêm SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>
<body class="/bg-gray-100 font-sans leading-normal tracking-normal">
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar -->
        <?php echo $__env->make('admin.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
            <!-- Navbar -->
            <?php echo $__env->make('admin.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Content -->
            <main class="flex-grow /p-6">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <!-- Footer -->
            <?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    

    <!-- JavaScript Libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    



    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script> -->

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\DATN\datnnew\SuViet_Project\SuViet_Project\SuViet_Project\resources\views/admin/master.blade.php ENDPATH**/ ?>