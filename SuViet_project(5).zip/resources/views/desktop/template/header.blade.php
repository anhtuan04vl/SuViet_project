@extends('admin.master')

@section('title', 'Dashboard')

@section('content')

@endsection