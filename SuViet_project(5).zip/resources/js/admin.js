import 'bootstrap/dist/css/bootstrap.min.css'; // Import CSS của Bootstrap
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; // Import JavaScript của Bootstrap

import '../css/style.css';
import '../css/bootstrap.min.css';
import './main.js'; // CSS chinh


